package com.example.noter;

import java.util.Date;

public class Note {

    public Date creation;
    public Date lastModified;

    public String content;

}
